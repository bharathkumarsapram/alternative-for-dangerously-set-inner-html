# HTMLRenderer Component (CUSTOM)

## Overview

The `HTMLRenderer` component is a React component designed to render HTML content as React elements. It takes an HTML string as input and converts it into a hierarchy of React nodes, preserving the structure and styling defined in the HTML.

## How to Use

To use the `HTMLRenderer` component, follow these steps:

1. Import the `HTMLRenderer` component into your React application:

   ```javascript
   import HTMLRenderer from "./HTMLRenderer";
   ```

2. Pass the HTML content you want to render as a string to the `html` prop of the `HTMLRenderer` component:

   ```javascript
   const htmlContent = "<div><p>Hello, <strong>world</strong>!</p></div>";
   <HTMLRenderer html={htmlContent} />;
   ```

## Explanation of the Code

The `HTMLRenderer` component consists of several parts:

1. **HTMLRendererProps Interface**: This interface defines the props expected by the `HTMLRenderer` component, such as `html`.

2. **HTMLRenderer Component**: This functional component receives the `html` prop, parses it, and renders it as React elements.

3. **parseHTML Function**: This function parses the HTML string using `DOMParser` and converts it into an array of React nodes. It iterates over each child node of the parsed document's body and calls the `parseNode` function to convert each node into a React node.

4. **parseNode Function**: This function converts each node of the HTML document into a React node. It handles different node types (text and element nodes) and recursively parses child nodes.

5. **parseStyle Function**: This helper function parses a CSS style string into a JavaScript object representing CSS properties.

6. **isVoidElement Function**: This helper function checks if a given tag name corresponds to a void HTML element.

## Example

Below is an example usage of the `HTMLRenderer` component:

```javascript
import HTMLRenderer from "./HTMLRenderer";

const htmlContent = "<div><p>Hello, <strong>world</strong>!</p></div>";
<HTMLRenderer html={htmlContent} />;
```
# DOMPurify 

- It is used to detect potentially malicious parts ( i.e :  cross-site scripting (XSS) attacks e.t.c ) in HTML code and then outputs a clean and safe version of it.

# React-html-parser (Package) : 

- A utility for converting HTML strings into React components. Avoids the use of dangerouslySetInnerHTML and converts standard HTML elements, attributes and inline styles into their React equivalents. 

### RESOURCES 

- https://blog.logrocket.com/using-dangerouslysetinnerhtml-react-application/