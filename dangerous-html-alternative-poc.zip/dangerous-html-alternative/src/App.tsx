import React, { useState } from 'react';
import JoditReact from 'jodit-react-ts';
import "jodit/build/jodit.min.css";
import './App.css';
import * as DOMPurify from 'dompurify';
import ReactHtmlParser from 'react-html-parser';
import HTMLRenderer from './components/htmlRenderer';
import sanitizeHTML from './components/pruifyer';

const App = () => {
  const [content, setContent] = useState<string>();

  // handle change event for ck editor
  const handleEditorChange = (content: string) => {
    setContent(content)
  }
  // CK editor configuration
  const CK_EDITOR_CONFIGURATION = {
    readonly: false,
    autofocus: false,
    tabIndex: 1,
    askBeforePasteFromWord: false,
    askBeforePasteHTML: false,
    defaultActionOnPaste: 'insert_clear_html',
    placeholder: 'write something awesome ...',
    beautyHTML: true,

    toolbarButtonSize: 'large',
    uploader: { insertImageAsBase64URI: true },
    buttons: 'bold,italic,underline,strikethrough,eraser,ul,ol,font,fontsize,paragraph,lineHeight,superscript,subscript,spellcheck,cut,copy,paste,selectall,hr,table,link,indent,outdent,brush,undo,redo,source,align,image',
    disablePlugins: 'inline-popup,image-properties',
  };
  
  // Here the content coming from ck editor is sanitized using DOMPurify plugin
  const data = content ? DOMPurify.sanitize(content) : '';

  console.log(data)
  const sanitize =content&& sanitizeHTML(content);
  return (
    <div className="App">
      <h3>Sanitizination of HTML string using DOMPurify and injecting to dangerouslySetInnerHTML</h3>
      
      <div>
        <JoditReact onChange={handleEditorChange} config={CK_EDITOR_CONFIGURATION} defaultValue={''} />
        <div dangerouslySetInnerHTML={{ __html: data }}></div>
      </div>

      <h3>Sanitizination of HTML string using DOMPurify and injecting to ReactHtmlParser</h3>

      <div>{data && ReactHtmlParser(data)}</div>

      <h3>Sanitizination of HTML string using DOMPurify and injecting to custom </h3>

      <HTMLRenderer html={sanitize ?? ''} />
    </div>
  );
}

export default App;
