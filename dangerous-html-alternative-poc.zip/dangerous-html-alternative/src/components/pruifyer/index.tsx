export default function sanitizeHTML(html: string): string {
    // Define the allowed tags and attributes
    const allowedTags: string[] = ['p', 'a', 'img', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
    const allowedAttributes: { [key: string]: string[] } = {
        'a': ['href'],
        'img': ['src', 'alt']
    };          

    // Create a temporary element to parse the HTML
    const tempElement = document.createElement('div');
    tempElement.innerHTML = html;

    // Traverse through all elements and attributes and remove any disallowed ones
    const traverse = (node: HTMLElement) => {
        // Remove disallowed tags
        if (!allowedTags.includes(node.tagName.toLowerCase())) {
            node.parentNode?.removeChild(node);
            return;
        }

        // Remove disallowed attributes
        const allowedAttrs = allowedAttributes[node.tagName.toLowerCase()] || [];
        Array.from(node.attributes).forEach(attr => {
            if (!allowedAttrs.includes(attr.name.toLowerCase())) {
                node.removeAttribute(attr.name);
            }
        });

        // Recursively traverse child nodes
        Array.from(node.childNodes).forEach(child => {
            if (child.nodeType === 1 /* ELEMENT_NODE */) {
                traverse(child as HTMLElement);
            }
        });
    };

    // Start traversing from the top-level children
    Array.from(tempElement.children).forEach(child => {
        traverse(child as HTMLElement);
    });

    // Return the sanitized HTML
    return tempElement.innerHTML;
}