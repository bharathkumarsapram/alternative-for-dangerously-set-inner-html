import React from 'react';

interface HTMLRendererProps {
  html: string;
}

const HTMLRenderer: React.FC<HTMLRendererProps> = ({ html }) => {
  // Parse the HTML string and convert it into React elements
  const parseHTML = (html: string): React.ReactNode[] => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const elements: React.ReactNode[] = [];
    console.log(doc,'doc')
    // Iterate over each child node and convert it into React element
    doc.body.childNodes.forEach(node => {
      const element = parseNode(node);
      elements.push(element);
    });

    return elements;
  };

  // Convert each node into React element recursively
  const parseNode = (node: Node): React.ReactNode => {
    if (node.nodeType === Node.TEXT_NODE) {
      return node.textContent;
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const element = node as Element;
      const tagName = element.tagName.toLowerCase();
      const props: { [key: string]: string | React.CSSProperties } = {}; // Adjust the type definition to accept CSSProperties for style
      // // Convert attributes into props

      Array.from(element.attributes).forEach(({ name, value }) => {
        if (name === 'style') {
          // Parse the style attribute into an object
          props[name] = parseStyle(value);
        } else {
          props[name] = value;
        }
      });

      const children: React.ReactNode[] = [];

      if (tagName === 'textarea') {
        // For textarea, set the value prop to its text content
        props['value'] = element.textContent ?? '';
      } else if (!isVoidElement(tagName)) {
        // For other non-void elements, parse their children
        Array.from(element.childNodes).forEach(childNode => {
          const child = parseNode(childNode);
          children.push(child);
        });
      }

      // Only create React element if it's not a void element
      if (isVoidElement(tagName)) {
        return React.createElement(tagName, { ...props });
      } else {
        return React.createElement(tagName, props, children);
      }

    } else {
      return null; // Ignore other types of nodes
    }
  };

  // Render the parsed React elements
  const reactElements = parseHTML(html);

  return <div>{reactElements}</div>;
};

// Helper function to parse style attribute into an object
const parseStyle = (styleString: string): React.CSSProperties => {
  const styleObject: React.CSSProperties = {};
  styleString.split(';').forEach(style => {
    const [key, value] = style.split(':');
    if (key && value) {
      const trimmedKey = key.trim();
      (styleObject as any)[trimmedKey] = value.trim();
    }
  });
  return styleObject;
};

// Method that checks void element tags 
const isVoidElement = (tagName: string): boolean => {
  // List of void element tags
  const voidElements = ['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'];
  return voidElements.includes(tagName);
};

export default HTMLRenderer;
